import sys
import os
sys.path.append(os.path.join(os.getcwd(), 'backend'))

from main import app
from utils.postman_generator import generate_postman_collection

if __name__ == "__main__":
    root_dir = os.getcwd()
    postman_path = os.path.join(root_dir, "postman.json")
    generate_postman_collection(app, postman_path)
    print(f"Postman collection updated at {postman_path}")
