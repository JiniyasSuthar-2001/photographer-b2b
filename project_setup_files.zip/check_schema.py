from sqlalchemy import create_engine, inspect
engine = create_engine("sqlite:///backend/lumiere.db")
inspector = inspect(engine)
columns = [c['name'] for c in inspector.get_columns('jobs')]
print(f"Columns in jobs: {columns}")
